This mod restores an old debug feature that allows you to make a save at any point in the game.
A 'Debug Save' option to the menu bar when playing in windowed mode.
