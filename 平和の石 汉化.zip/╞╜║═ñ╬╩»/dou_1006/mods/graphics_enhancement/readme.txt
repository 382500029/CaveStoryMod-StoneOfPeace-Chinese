This mod improves the game's graphical capabilities in various ways:

It allows you to customise the aspect ratio, thus adding widescreen support.

You can also resize the game's window beyond the original 640x480 limit.

In addition, you can enable the game to use higher-definition sprite sets.

There's also the option to change the game's framerate from 50 to 60, to match the prototype version of the game,
and the Nicalis releases.

Finally, the mod also adds V-Sync and a borderless fullscreen mode.

For more information, read this: https://www.cavestory.org/forums/threads/graphics-enhancement-pack-mod.13920/